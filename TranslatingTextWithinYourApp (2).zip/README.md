# Translating text within your app

This sample app demonstrates how to use the Translation framework to offer in-app translations from one language to another.
The app translates one or more strings of text, and shows you how to prepare for a translation and check for language availability.

For more information about the app and how it works, see
[Translating text within your app](https://developer.apple.com/documentation/translation/translating-text-within-your-app).
